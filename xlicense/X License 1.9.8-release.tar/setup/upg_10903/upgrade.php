<?php
/**
 * @brief       Upgrade to 1.9.3
 * @author      XENNTEC UG
 */

namespace IPS\xlicense\setup\upg_10903;

class _Upgrade
{
	/**
	 * Discard the cached server config. Configs stored before 1.9.3 were
	 * fetched without certificate verification, so a spoofed endpoint list
	 * could persist for its full cache_hours. Wiping it forces the next
	 * license check to refetch over the now-verified transport.
	 *
	 * @return	TRUE
	 */
	public function step1()
	{
		try
		{
			\IPS\Settings::i()->changeValues( array( 'xenntec_lic_config' => '' ) );
			\IPS\Data\Store::i()->clearAll();
			\IPS\Settings::i()->clearCache();
		}
		catch ( \Exception $e )
		{
			// Setting may not exist yet on this install; nothing to invalidate
		}

		return TRUE;
	}
}
