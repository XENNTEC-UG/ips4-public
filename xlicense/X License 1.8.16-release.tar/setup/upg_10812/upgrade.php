<?php
/**
 * @brief       Upgrade to 1.8.12
 * @author      XENNTEC UG
 */

namespace IPS\xlicense\setup\upg_10812;

class _Upgrade
{
	/**
	 * Remove the unused legacy license registry table.
	 *
	 * @return	TRUE
	 */
	public function step1()
	{
		if ( \IPS\Db::i()->checkForTable( 'xenntec_license_registry' ) )
		{
			\IPS\Db::i()->dropTable( 'xenntec_license_registry' );
		}

		return TRUE;
	}
}
