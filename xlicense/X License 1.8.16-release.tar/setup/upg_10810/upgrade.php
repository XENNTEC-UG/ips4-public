<?php

namespace IPS\xlicense\setup\upg_10810;

/* To prevent PHP errors (extending class does not exist) revealing path */
if ( !defined( '\IPS\SUITE_UNIQUE_KEY' ) )
{
	header( ( isset( $_SERVER['SERVER_PROTOCOL'] ) ? $_SERVER['SERVER_PROTOCOL'] : 'HTTP/1.0' ) . ' 403 Forbidden' );
	exit;
}

/**
 * 1.8.10 Upgrade — Self-heal hook registration for all installed XENNTEC apps
 *
 * Apps installed through xlicense before v1.8.9 could end up with their hooks
 * dead on hosts running opcache.validate_timestamps=0: installHooks() wrote
 * /plugins/hooks.php but OPcache kept serving the stale pre-install copy, so
 * the hooks never went live (symptom: a payment gateway app installs cleanly
 * but never appears in Commerce > Payments). v1.8.9 fixed the install flow
 * going forward; this step retroactively heals every already-installed app by
 * reseeding core_hooks from each app's data/hooks.json, rewriting the compiled
 * hooks map, and force-invalidating the OPcache entry for it.
 */
class _Upgrade
{
	/**
	 * Step 1: Reseed hooks for installed XENNTEC apps + force OPcache drop of /plugins/hooks.php
	 *
	 * Never fails the upgrade: all work is best-effort, problems are logged.
	 *
	 * @return	array|TRUE
	 */
	public function step1()
	{
		$logTag = 'xlicense_upgrade';

		try
		{
			$healed = array();

			foreach ( array_keys( \IPS\xlicense\License\Checker::getRegistry() ) as $dir )
			{
				try
				{
					$app = \IPS\Application::load( $dir );
				}
				catch ( \OutOfRangeException $e )
				{
					continue;
				}

				try
				{
					/* Idempotent: core deletes the app's core_hooks rows, reinserts from
					   data/hooks.json, and rewrites /plugins/hooks.php */
					$app->installHooks();
					$healed[] = $dir;
				}
				catch ( \Throwable $e )
				{
					\IPS\Log::log( "[upg_10810] installHooks failed for {$dir}: " . $e->getMessage(), $logTag );
				}
			}

			/* No registry app installed: still rebuild the compiled map once */
			if ( !\count( $healed ) )
			{
				\IPS\Plugin\Hook::writeDataFile();
			}

			/* Core writeDataFile() invalidates without the force flag, which is a no-op
			   under opcache.validate_timestamps=0. Force it. Skipped on Cloud, where
			   hooks.php is not a local file. */
			$compiledPath = \IPS\ROOT_PATH . '/plugins/hooks.php';
			if ( !\IPS\CIC2 )
			{
				if ( \function_exists( 'opcache_invalidate' ) )
				{
					@opcache_invalidate( $compiledPath, TRUE );
				}
				\clearstatcache( TRUE, $compiledPath );

				/* Verify each healed app's weld actually landed in the compiled map.
				   file_get_contents reads from disk, bypassing OPcache. */
				$compiled = file_exists( $compiledPath ) ? (string) file_get_contents( $compiledPath ) : '';
				foreach ( $healed as $dir )
				{
					$hooksJsonPath = \IPS\ROOT_PATH . '/applications/' . $dir . '/data/hooks.json';
					if ( !file_exists( $hooksJsonPath ) )
					{
						continue;
					}
					$expected = json_decode( (string) file_get_contents( $hooksJsonPath ), true );
					if ( !\is_array( $expected ) || !\count( $expected ) )
					{
						continue;
					}
					if ( \strpos( $compiled, $dir . '_hook_' ) === false )
					{
						\IPS\Log::log( "[upg_10810] Compiled hooks.php is missing the weld for {$dir} (check /plugins write permissions)", $logTag );
					}
				}
			}

			\IPS\Log::log( '[upg_10810] Hook self-heal complete for: ' . ( \count( $healed ) ? implode( ', ', $healed ) : '(none installed)' ), $logTag );
		}
		catch ( \Throwable $e )
		{
			\IPS\Log::log( '[upg_10810] Self-heal step failed: ' . $e->getMessage(), $logTag );
		}

		return TRUE;
	}
}
